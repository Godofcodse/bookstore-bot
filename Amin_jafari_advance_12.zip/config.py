import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# 🔴 **اصلاح مهم: استفاده از نام سرویس Runflare**
# اگر در Runflare هستیم، از نام سرویس استفاده می‌کنیم
RUNFLARE_SERVICE_NAME = os.getenv("RUNFLARE_SERVICE_NAME")

# تنظیمات دیتابیس
DB_CONFIG = {
    "host": RUNFLARE_SERVICE_NAME if RUNFLARE_SERVICE_NAME else os.getenv("DB_HOST", "10.98.165.30"),
    "database": os.getenv("DB_NAME", "bookstorwej_db"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "j1iCdNuuIJLvn1CDdy7i"),
    "port": os.getenv("DB_PORT", "3306"),
}

# Telegram Bot Settings
BOT_TOKEN = os.getenv("BOT_TOKEN")
try:
    ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
except:
    ADMIN_ID = 0

# Payment Settings
PAYMENT_CARD = os.getenv("PAYMENT_CARD")

# Other Settings
MAX_SEARCH_RESULTS = 5
CART_TIMEOUT = 3600

# Validation
if not BOT_TOKEN:
    raise ValueError("❌ BOT_TOKEN not found in environment variables")
if ADMIN_ID == 0:
    print("⚠️ Warning: ADMIN_ID not found or invalid, using default")

# اطلاع‌رسانی در مورد تنظیمات دیتابیس
print(f"📊 تنظیمات دیتابیس:")
print(f"   Host: {DB_CONFIG['host']}")
print(f"   Database: {DB_CONFIG['database']}")
print(f"   User: {DB_CONFIG['user']}")